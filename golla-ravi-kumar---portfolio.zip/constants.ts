import { Profile } from './types';

export const PROFILE_DATA: Profile = {
  name: "Golla Ravi Kumar",
  title: "Aspiring Java Full Stack Developer",
  location: "Adoni, Andhra Pradesh, India",
  linkedin: "https://www.linkedin.com/in/golla-ravi-kumar18",
  summary: "I am a Dedicated Computer Science student with a strong interest in technology and a thirst for knowledge. I'm passionate about coding, software development, and problem solving. Currently pursuing my degree in computer science and engineering at Mohan Babu University. I'm excited to turn my passion into a rewarding career in the tech world.",
  skills: [
    "JavaScript",
    "Java Development",
    "Object-Oriented Programming (OOP)",
    "HTML5",
    "CSS3",
    "Backend Java",
    "Spring Framework",
    "Hibernate"
  ],
  education: [
    {
      institution: "Mohan Babu University",
      degree: "Bachelor of Technology - BTech, Computer Science and Engineering",
      period: "2023 - 2027"
    },
    {
      institution: "Gsh Junior College",
      degree: "Intermediate, MPC",
      period: "September 2021 - May 2023"
    },
    {
      institution: "Novy High School",
      degree: "Secondary School",
      period: "May 2018 - May 2021"
    }
  ],
  certifications: [
    { name: "JavaScript Essentials 1" },
    { name: "Full Stack Programming (HTML5, CSS3, JavaScript & Backend Java)" },
    { name: "Java Developer Certification" },
    { name: "Spring & Hibernate for Java Developers" }
  ]
};

export const INITIAL_CHAT_MESSAGE = "Hi! I'm Ravi's AI assistant. Ask me anything about his skills, education, or experience.";