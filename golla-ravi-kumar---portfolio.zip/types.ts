export interface Education {
  institution: string;
  degree: string;
  period: string;
}

export interface Certification {
  name: string;
  issuer?: string; // Inferred or optional
}

export interface Profile {
  name: string;
  title: string;
  location: string;
  linkedin: string;
  summary: string;
  skills: string[];
  education: Education[];
  certifications: Certification[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}