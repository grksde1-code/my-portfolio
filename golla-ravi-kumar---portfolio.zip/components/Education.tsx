import React from 'react';
import { PROFILE_DATA } from '../constants';
import { GraduationCap } from './Icons';

const Education: React.FC = () => {
  return (
    <section id="education" className="py-24 bg-white">
      <div className="container mx-auto px-6">
        <div className="mb-16">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Education</h2>
            <div className="w-20 h-1 bg-blue-600 rounded-full"></div>
        </div>

        <div className="space-y-12 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-slate-300 before:to-transparent">
          {PROFILE_DATA.education.map((edu, index) => (
            <div key={index} className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
              
              {/* Icon */}
              <div className="flex items-center justify-center w-10 h-10 rounded-full border-2 border-slate-300 bg-white shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 z-10 text-slate-500 group-hover:border-blue-500 group-hover:text-blue-500 transition-colors">
                <GraduationCap size={18} />
              </div>
              
              {/* Card */}
              <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] bg-white p-6 rounded-xl border border-slate-100 shadow-sm hover:shadow-lg transition-shadow">
                <div className="flex flex-col sm:flex-row justify-between mb-1">
                  <h3 className="font-bold text-slate-900 text-lg">{edu.institution}</h3>
                  <time className="text-xs font-medium uppercase text-blue-600 sm:text-right mt-1 sm:mt-0">{edu.period}</time>
                </div>
                <div className="text-slate-600 font-medium">{edu.degree}</div>
              </div>

            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Education;