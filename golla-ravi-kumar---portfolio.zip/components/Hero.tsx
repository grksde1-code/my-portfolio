import React from 'react';
import { PROFILE_DATA } from '../constants';
import { Linkedin, MapPin, Mail } from './Icons';

const Hero: React.FC = () => {
  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden bg-slate-50">
      <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 bg-blue-100 rounded-full blur-3xl opacity-50"></div>
      <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-72 h-72 bg-indigo-100 rounded-full blur-3xl opacity-50"></div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-3xl">
          <div className="inline-block px-3 py-1 mb-4 text-xs font-semibold tracking-wider text-blue-600 uppercase bg-blue-50 rounded-full border border-blue-100">
            Available for Opportunities
          </div>
          <h1 className="text-5xl md:text-7xl font-extrabold text-slate-900 tracking-tight mb-6">
            Hello, I'm <br/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">
              {PROFILE_DATA.name}
            </span>
          </h1>
          <p className="text-xl md:text-2xl text-slate-600 mb-8 leading-relaxed max-w-2xl">
            {PROFILE_DATA.title}. Passionate about building scalable backend systems and modern web applications.
          </p>
          
          <div className="flex flex-wrap gap-4 items-center text-slate-500 mb-10">
            <div className="flex items-center gap-2">
              <MapPin size={18} />
              <span>{PROFILE_DATA.location}</span>
            </div>
             <a href={PROFILE_DATA.linkedin} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 hover:text-blue-600 transition-colors">
              <Linkedin size={18} />
              <span>LinkedIn</span>
            </a>
          </div>

          <div className="flex gap-4">
             <button 
               onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}
               className="px-8 py-3 bg-slate-900 text-white rounded-lg font-medium hover:bg-slate-800 transition-all shadow-lg hover:shadow-xl"
             >
               View Work
             </button>
             <button 
               onClick={() => window.open(PROFILE_DATA.linkedin, '_blank')}
               className="px-8 py-3 bg-white text-slate-900 border border-slate-200 rounded-lg font-medium hover:border-blue-300 hover:text-blue-600 transition-all"
             >
               Contact Me
             </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;