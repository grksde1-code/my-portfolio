import React from 'react';
import { PROFILE_DATA } from '../constants';
import { Code2 } from './Icons';

const Skills: React.FC = () => {
  return (
    <section id="skills" className="py-24 bg-slate-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Technical Skills</h2>
          <p className="text-slate-600 max-w-2xl mx-auto">
            A comprehensive list of the technologies and methodologies I have worked with during my academic and project journey.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {PROFILE_DATA.skills.map((skill, index) => (
            <div 
              key={index}
              className="bg-white p-6 rounded-xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow flex flex-col items-center justify-center text-center group"
            >
              <div className="mb-4 p-3 bg-blue-50 rounded-full text-blue-600 group-hover:scale-110 transition-transform duration-300">
                <Code2 size={24} />
              </div>
              <span className="font-semibold text-slate-800">{skill}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;