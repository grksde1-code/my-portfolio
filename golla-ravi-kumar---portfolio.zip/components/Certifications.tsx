import React from 'react';
import { PROFILE_DATA } from '../constants';
import { Award } from './Icons';

const Certifications: React.FC = () => {
  return (
    <section id="certifications" className="py-24 bg-slate-50">
      <div className="container mx-auto px-6">
        <div className="mb-16">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Certifications</h2>
             <div className="w-20 h-1 bg-blue-600 rounded-full"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
          {PROFILE_DATA.certifications.map((cert, index) => (
            <div key={index} className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 flex items-start gap-4 hover:border-blue-200 transition-colors">
              <div className="p-3 bg-amber-50 rounded-xl text-amber-500 shrink-0">
                <Award size={28} />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900 mb-2">{cert.name}</h3>
                <p className="text-slate-500 text-sm">Professional Certification</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Certifications;