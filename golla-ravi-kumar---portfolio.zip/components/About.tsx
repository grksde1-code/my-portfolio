import React from 'react';
import { PROFILE_DATA } from '../constants';
import { User } from './Icons';

const About: React.FC = () => {
  return (
    <section id="about" className="py-24 bg-white">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row gap-12 items-start">
          <div className="w-full md:w-1/3">
            <div className="bg-slate-50 rounded-2xl p-8 border border-slate-100 sticky top-24">
              <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mb-6 text-blue-600">
                <User size={32} />
              </div>
              <h3 className="text-2xl font-bold text-slate-900 mb-2">About Me</h3>
              <p className="text-slate-500">A glimpse into my professional journey and passion for technology.</p>
            </div>
          </div>
          
          <div className="w-full md:w-2/3">
            <h2 className="text-3xl font-bold text-slate-900 mb-8">Summary</h2>
            <div className="prose prose-lg text-slate-600 leading-relaxed">
              <p>{PROFILE_DATA.summary}</p>
            </div>
            
            <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="p-6 bg-slate-50 rounded-xl border border-slate-100">
                    <h4 className="font-semibold text-slate-900 mb-2">Focus</h4>
                    <p className="text-slate-600">Java Backend, Modern Web Development, Problem Solving</p>
                </div>
                 <div className="p-6 bg-slate-50 rounded-xl border border-slate-100">
                    <h4 className="font-semibold text-slate-900 mb-2">Education Status</h4>
                    <p className="text-slate-600">Pursuing BTech CSE (2023-2027) at Mohan Babu University</p>
                </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;