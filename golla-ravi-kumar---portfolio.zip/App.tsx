import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Skills from './components/Skills';
import Education from './components/Education';
import Certifications from './components/Certifications';
import Chatbot from './components/Chatbot';

const App: React.FC = () => {
  return (
    <div className="min-h-screen relative">
      <Navbar />
      <main>
        <Hero />
        <About />
        <Skills />
        <Education />
        <Certifications />
      </main>
      
      <footer className="bg-slate-900 py-12 text-center text-slate-400">
        <div className="container mx-auto px-6">
          <p>© {new Date().getFullYear()} Golla Ravi Kumar. All rights reserved.</p>
          <p className="text-sm mt-2 opacity-60">Built with React, Tailwind & Gemini AI</p>
        </div>
      </footer>

      <Chatbot />
    </div>
  );
};

export default App;