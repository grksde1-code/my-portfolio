import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";
import { PROFILE_DATA } from '../constants';

const API_KEY = process.env.API_KEY || '';

let chatSession: Chat | null = null;

const SYSTEM_INSTRUCTION = `
You are an AI assistant for Golla Ravi Kumar's portfolio website.
Your persona is professional, enthusiastic, and knowledgeable about Ravi's background.
You speak in the first person plural (e.g., "We", "Ravi") or third person when referring to him, but primarily act as a helpful representative.

Here is Ravi's resume data to use as your knowledge base:
${JSON.stringify(PROFILE_DATA, null, 2)}

Rules:
1. Answer questions strictly based on the provided resume data.
2. If asked about something not in the resume (like specific work experience not listed, or personal phone number), politely say you don't have that information.
3. Keep answers concise and relevant to a recruiter or potential employer.
4. Highlight his passion for Java Full Stack development when relevant.
5. If the user greets you, welcome them to the portfolio.
`;

export const initializeChat = (): Chat => {
  if (!API_KEY) {
    console.warn("Gemini API Key is missing.");
    // We return a dummy object or handle this in the UI, but strictly type-wise we need a Chat object.
    // For safety in this demo, we'll try to initialize but the calls will fail if key is bad.
  }

  const ai = new GoogleGenAI({ apiKey: API_KEY });
  chatSession = ai.chats.create({
    model: 'gemini-3-flash-preview',
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
    },
  });
  return chatSession;
};

export const sendMessageToGemini = async (message: string): Promise<string> => {
  if (!chatSession) {
    initializeChat();
  }

  if (!chatSession) {
    return "Error: AI Service not initialized. Please check API Key.";
  }

  try {
    const response: GenerateContentResponse = await chatSession.sendMessage({
        message: message
    });
    return response.text || "I'm sorry, I couldn't generate a response.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I'm having trouble connecting to the server right now. Please try again later.";
  }
};